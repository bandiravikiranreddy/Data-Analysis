import java.io.*;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import bookfilesBeans.Book;//Get Book beans
import bookfilesBeans.Sales;//Get Sales beans

public class booksales {

 

       public static void main(String[] args) {

             

              List<Book> books = readFromBookCsv("D:\\book.csv");
              List<Sales> sales = readFromSalesCsv("D:\\sales.csv");

              for (Book b : books)
              {
                     System.out.println(b);
              }
              for (Sales s : sales)

              {
                     System.out.println(s);
              }

             

              //top two book sellings

              getTopTwoBook(books,sales);

             

              //getTopCustomers

             

              getTopCustomer(books, sales, 1);

             

              getSalesOnDt(books, sales, "8/1/2018");

             

       }

             
       		//Reading books csv
              public static List<Book> readFromBookCsv(String path)

              {

                     List<Book> bookList = new ArrayList<>();

                     Path pathToFile = Paths.get(path);//get the relative path and converts abstrsct path name into path name string                   

                     try(BufferedReader br = Files.newBufferedReader(pathToFile,StandardCharsets.US_ASCII))

                     {

                           String line ="";

                           br.readLine(); //skip the first line          

                           while((line = br.readLine()) != null)

                           {
                                  	String[] data = line.split(",");//Splitting according to comma
                                  	if(data.length > 0)
			                       {
                                  			String  book_id = data[0];
		
		                                    String  book_title = data[1];
		
		                                    String  book_author = data[2];
		
		                                    Float  book_price = Float.parseFloat(data[3]);
	                                         
		                                    bookList.add(new Book(book_id, book_title, book_author, book_price));
	                                }

                           }

                     }catch(IOException e)
                     {
                           System.out.println(e);
                     }

                               return bookList;
              	}

             

              public static List<Sales> readFromSalesCsv(String path)

              {

                     List<Sales> salesList = new ArrayList<>();

                     Path pathToFile = Paths.get(path);

                     try(BufferedReader br = Files.newBufferedReader(pathToFile,StandardCharsets.US_ASCII))

                     {

                           String line = "";
                           br.readLine();
                           while((line = br.readLine()) != null)
                           {

                                  String[] data = line.split(",");
                                  if(data.length > 0)
                                  {
                                         String sale_date = data[0];

                                         String sale_email = data[1];

                                         String sale_payment_method = data[2];

                                         int sale_item_count = Integer.parseInt(data[3]);

                                         String book_id = "";

                                         int book_quantity = 0;

                                         for(int i=1; i <= sale_item_count ; i++) {

                                                String bookSold = data[3+i];

                                                String[] bookDet = bookSold.split(";");

                                                book_id = bookDet[0];

                                                book_quantity = Integer.parseInt(bookDet[1]);

                                                salesList.add(new Sales(sale_date,sale_email,sale_payment_method,sale_item_count,book_id,book_quantity)); 

                                         }
                                  }
                          }
                     }catch(IOException e)
                     {
                           System.out.println("File Cannot be read");
                     }

                     return salesList;
              }

             

              public static void getTopTwoBook(List<Book> books,List<Sales> sales) {

                     //top two book sellings
            	  	 String topBook1 = "";

                     String topBook2 = "";

                     int topBook1Count = 0;

                     int topBook2Count = 0;
                     
                     for (Book b : books)

                     {

                           int count =0;

                           for (Sales s : sales)

                           {

                                  if(b.getBook_id().equalsIgnoreCase(s.getBook_id())) {

                                         count = count+ s.getBook_quantity();

                                  }

                           }

                           if(topBook1Count < count){

                                  topBook2Count = topBook1Count;

                                  topBook1Count =count;

                                  topBook1 = b.getBook_id();

                                  topBook2 = topBook1;

                   } else if(topBook2Count < count){

                     topBook2Count = count;

                     topBook2 = b.getBook_id();

                   }

                           System.out.println("Top_selling_books\t"+b.getBook_id() + "  ---  "+count);

                     }

                     System.out.println("First Top Book\t"+topBook1 + "  ---  "+topBook1Count);

                     System.out.println("Second Top Book\t"+topBook2 + "  ---  "+topBook2Count);

             }

             

              public static void getTopCustomer(List<Book> books,List<Sales> sales,int top) {

                     //top two book sellings
            	  		  Map<String,Integer> map = new HashMap<>();                          

                           for (Sales s : sales)

                           {

                                  //System.out.println(s.getSale_email()+ "  ----  "+s.getSale_item_count());

                                  if(map.get(s.getSale_email()) !=null) {

                                         int count = map.get(s.getSale_email()) +s.getSale_item_count();

                                         map.put(s.getSale_email(), count);

                                  }else {

                                         map.put(s.getSale_email(), s.getSale_item_count());                                     

                                  }

                           }

                          map = sortByValue(map);
                          
                          Collection<String> keyset = map.keySet();

                           int val =1;

                           Iterator<String> it = keyset.iterator();

                           while ( it.hasNext()) {

                                  if(val>top) {

                                         break;

                               }else {

                                  val++;

                                  String value = it.next();

                                  System.out.println("Top Customer Mail\t"+value+"  --- " + map.get(value));

                                 

                               }

                           }
              			}

                 private static Map<String, Integer> sortByValue(Map<String, Integer> unsortMap) {

 

                      // 1. Convert Map to List of Map

                      List<Map.Entry<String, Integer>> list =

                      new LinkedList<Map.Entry<String, Integer>>(unsortMap.entrySet());

                      // 2. Sort list with Collections.sort(), provide a custom Comparator

                      //    Try switch the o1 o2 position for a different order

                      Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {

                          public int compare(Map.Entry<String, Integer> o1,

                                             Map.Entry<String, Integer> o2) {

                              return (o2.getValue()).compareTo(o1.getValue());

                          }

                      });

 

                      // 3. Loop the sorted list and put it into a new insertion order Map LinkedHashMap

                      Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();

                      for (Map.Entry<String, Integer> entry : list) {

                          sortedMap.put(entry.getKey(), entry.getValue());

                      }

 

                      /*

                      //classic iterator example

                      for (Iterator<Map.Entry<String, Integer>> it = list.iterator(); it.hasNext(); ) {

                          Map.Entry<String, Integer> entry = it.next();

                          sortedMap.put(entry.getKey(), entry.getValue());

                      }*/

 

 

                      return sortedMap;

                  }

               

                

                public static void getSalesOnDt(List<Book> books,List<Sales> sales,String date) {

                      

                       int count = 0;

                       for (Sales s : sales)

                           {

                             if(s.getSale_date().equalsIgnoreCase(date)) {

                                    count = count +s.getSale_item_count();

                             }

                           }

                           System.out.println("Sales on Date\t"+date + "  ----- "+count);

                     }

 }

