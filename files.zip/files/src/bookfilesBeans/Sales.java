package bookfilesBeans;

public class Sales {
	
	private String sale_date;
	private String sale_email;
	private String sale_payment_method;
	private int sale_item_count;
	private String book_id;
	private int book_quantity;
	
	public Sales(String sale_date, String sale_email, String sale_payment_method, int sale_item_count,
			String book_id, int book_quantity) {
		this.sale_date = sale_date;
		this.sale_email = sale_email;
		this.sale_payment_method = sale_payment_method;
		this.sale_item_count = sale_item_count;
		this.book_id = book_id;
		this.book_quantity = book_quantity;
	}

	public String getSale_date() {
		return sale_date;
	}

	public void setSale_date(String sale_date) {
		this.sale_date = sale_date;
	}

	public String getSale_email() {
		return sale_email;
	}

	public void setSale_email(String sale_email) {
		this.sale_email = sale_email;
	}

	public String getSale_payment_method() {
		return sale_payment_method;
	}

	public void setSale_payment_method(String sale_payment_method) {
		this.sale_payment_method = sale_payment_method;
	}

	public int getSale_item_count() {
		return sale_item_count;
	}

	public void setSale_item_count(int sale_item_count) {
		this.sale_item_count = sale_item_count;
	}

	public String getBook_id() {
		return book_id;
	}

	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}

	public int getBook_quantity() {
		return book_quantity;
	}

	public void setBook_quantity(int book_quantity) {
		this.book_quantity = book_quantity;
	}

	@Override
	public String toString() {
		return "sales [sale_date=" + sale_date + ", sale_email=" + sale_email + ", sale_payment_method="
				+ sale_payment_method + ", sale_item_count=" + sale_item_count + ", book_id=" + book_id
				+ ", book_quantity=" + book_quantity + "]";
	}
	
	
	

}
